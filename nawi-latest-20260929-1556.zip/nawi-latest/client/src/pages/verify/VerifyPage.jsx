import React, { useState, useEffect } from 'react';
import { useSearchParams, useParams, useNavigate, Link } from 'react-router-dom';
import { verifyReport } from '../../services/report.service.js';
import StatusBadge from '../../components/common/StatusBadge.jsx';
import { useTranslation } from '../../config/i18n.js';
import { ShieldCheck, Search, AlertCircle, CheckCircle2 } from 'lucide-react';

export default function VerifyPage() {
  const [searchParams] = useSearchParams();
  const [query, setQuery] = useState(
    searchParams.get('hash') || searchParams.get('id') || searchParams.get('q') || ''
  );
  const { reportNumberOrHash } = useParams();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [networkError, setNetworkError] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleVerify = async (qToUse) => {
    const target = qToUse || query;
    if (!target.trim()) return;
    setLoading(true);
    setError(null);
    setNetworkError(null);
    setResult(null);
    try {
      const res = await verifyReport(target.trim());
      setResult(res.data || res);
    } catch (err) {
      if (err.response?.status === 404) {
        setError('No published report matches this number or hash. If you have just received the report, it may not be published yet.');
      } else {
        setNetworkError(err.response?.data?.error?.message || 'Unable to contact the verification service. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const integrityFailed = !result?.isIntegrityVerified;
  const isCurrentPublished = result?.isPublished && !result?.isSuperseded;
  const resultColor = integrityFailed || result?.isRevoked || result?.isSuperseded
    ? 'var(--gov-red)'
    : isCurrentPublished ? 'var(--gov-green)' : 'var(--gov-orange)';

  useEffect(() => {
    const deepLinkQuery = reportNumberOrHash || query;
    if (deepLinkQuery) {
      setQuery(deepLinkQuery);
      handleVerify(deepLinkQuery);
    }
  }, [reportNumberOrHash]);

  return (
    <div style={{ maxWidth: 800 }}>
      <div className="page-header">
        <div>
          <h1><ShieldCheck size={22} style={{ marginRight: 8, verticalAlign: -3 }} />{t('verify_portal')}</h1>
          <p className="page-header-subtitle">{t('page_subtitle_verify')}</p>
        </div>
      </div>

      {/* Search box */}
      <div className="gov-card mb-24">
        <div className="gov-card-body">
          <div className="gov-form-group">
            <label className="gov-label" htmlFor="verify-query">{t('verify_input')}</label>
            <div className="flex-gap-8">
              <input
                id="verify-query" className="gov-input"
                style={{ flex: 1 }}
                placeholder="e.g. NAWI-2026-000001 or 7f8a9b..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleVerify()}
              />
              <button className="gov-btn gov-btn-accent" onClick={() => handleVerify()} disabled={loading}>
                <Search size={16} /> {loading ? t('verifying') : t('verify_button')}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Error state */}
      {(error || networkError) && (
        <div className="gov-card mb-24" style={{ borderColor: networkError ? 'var(--gov-red)' : 'var(--gov-border)' }}>
          <div className="gov-card-body flex-gap-8" style={{ color: networkError ? 'var(--gov-red)' : 'var(--gov-text-body)' }}>
            <AlertCircle size={20} />
            <div>
              <strong>{networkError ? 'Verification service unavailable' : 'No published report found'}</strong>
              <p style={{ fontSize: 13, marginTop: 2 }}>{networkError || error}</p>
              <button type="button" className="gov-btn gov-btn-outline" style={{ marginTop: 8 }} onClick={() => navigate('/verify')}>Back to verification</button>
            </div>
          </div>
        </div>
      )}

      {/* Verification Result */}
      {result && (
        <div className="gov-card">
          <div className="gov-card-header" style={{ background: resultColor === 'var(--gov-red)' ? 'var(--gov-red-light)' : resultColor === 'var(--gov-green)' ? 'var(--gov-green-light)' : 'var(--gov-orange-light, #fff4e5)' }}>
            <div className="flex-gap-8">
              <CheckCircle2 size={20} color={resultColor} />
              <h3 style={{ color: resultColor }}>
                {result.isRevoked ? 'Report REVOKED' : result.isSuperseded ? 'Report SUPERSEDED' : integrityFailed ? 'Report integrity could not be verified' : isCurrentPublished ? 'Published report verified' : 'Report is not currently published'}
              </h3>
            </div>
            <StatusBadge status={result.overallVerdict || result.status} />
          </div>

          <div className="gov-card-body">
            {result.isRevoked && (
              <div className="gov-card mb-16" style={{ background: 'var(--gov-red-light)', border: '1px solid var(--gov-red)', color: 'var(--gov-red)', padding: 12 }}>
                <strong>{result.revocationReason || result.revocationNotice || 'WARNING: This report has been REVOKED'}</strong>
              </div>
            )}
            {result.isSuperseded && (
              <div className="gov-card mb-16" style={{ background: 'var(--gov-red-light)', border: '1px solid var(--gov-red)', color: 'var(--gov-red)', padding: 12 }}>
                This report has been superseded by {result.supersededByReportNumber ? <Link to={`/verify/${encodeURIComponent(result.supersededByReportNumber)}`}>{result.supersededByReportNumber}</Link> : 'a newer report'} and should not be used as the current certificate.
              </div>
            )}
            {!result.isRevoked && !result.isSuperseded && !result.isPublished && (
              <div className="gov-card mb-16" style={{ background: 'var(--gov-orange-light, #fff4e5)', padding: 12 }}>
                Integrity verification alone does not make a report official. Current status: <strong>{result.status}</strong>.
              </div>
            )}
            {result.isPublished && !result.isSuperseded && (
              <div className="gov-card mb-16" style={{ background: 'var(--gov-green-light)', padding: 12 }}>
                Published {result.publishedAt ? `on ${new Date(result.publishedAt).toLocaleString()}` : ''}.
              </div>
            )}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 16, fontSize: 14 }}>
              <div><span className="text-muted" style={{ fontSize: 12 }}>Report Number</span><br /><strong className="text-mono">{result.reportNumber || result._id}</strong></div>
              <div><span className="text-muted" style={{ fontSize: 12 }}>PDF integrity</span><br /><strong>{result.isIntegrityVerified ? 'Verified' : 'Could not verify stored PDF'}</strong></div>
              <div><span className="text-muted" style={{ fontSize: 12 }}>Published</span><br /><strong>{result.isPublished ? 'Yes' : 'No'}</strong></div>
              <div><span className="text-muted" style={{ fontSize: 12 }}>Digital signature</span><br /><strong>{result.isDigitalSignatureVerified ? 'Verified' : 'Not verified'}</strong></div>
              <div><span className="text-muted" style={{ fontSize: 12 }}>Signature type</span><br /><strong>{result.signatureType || '-'}</strong></div>
              <div><span className="text-muted" style={{ fontSize: 12 }}>Certificate fingerprint</span><br /><strong className="text-mono">{result.certificateFingerprint || '-'}</strong></div>
              <div><span className="text-muted" style={{ fontSize: 12 }}>Signer key ID</span><br /><strong className="text-mono">{result.signerKeyId || '-'}</strong></div>
              <div><span className="text-muted" style={{ fontSize: 12 }}>Overall result</span><br /><strong>{result.overallResult || result.overallVerdict || '-'}</strong></div>
              <div><span className="text-muted" style={{ fontSize: 12 }}>Accuracy Class</span><br /><strong>Class {result.accuracyClass || result.testSessionId?.accuracyClass || '—'}</strong></div>
              <div><span className="text-muted" style={{ fontSize: 12 }}>Serial Number</span><br /><strong className="text-mono">{result.serialNumber || result.testSessionId?.serialNumber || '—'}</strong></div>
              <div style={{ gridColumn: '1 / -1' }}>
                <span className="text-muted" style={{ fontSize: 12 }}>SHA-256 Document Hash</span><br />
                <code className="text-mono" style={{ fontSize: 12, wordBreak: 'break-all', background: 'var(--gov-bg-page)', padding: '6px 10px', borderRadius: 4, display: 'block', marginTop: 4 }}>
                  {result.contentHash || 'No stored PDF hash'}
                </code>
              </div>
              <p style={{ gridColumn: '1 / -1' }}>The stored HMAC is an integrity check and does not provide a PKI-based digital signature or independent legal signer verification.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
